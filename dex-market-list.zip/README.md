# dex-market-list
Export activate market list of 3 DEX(Pancakeswap, Uniswap, Sushiswap) to .csv files.
